// Handledare: Jimmy Åhlander
// Student: Only Badle
// Redigerat: 15/8/2023
// betyg E
#include "klass.h"

int main()
{
    const int numrows = 6;
    const int numcoloumns = 6;
    srand(static_cast<unsigned>(time(0))); // Seed the random number generator

    while (true)
    {
        std::cout << "Gör ett val: " << std::endl;
        std::cout << "1- Generera Labyrinter" << std::endl;
        std::cout << "2- Avsluta programmet." << std::endl;
        Maze Getinput(numrows, numcoloumns);
        int choice = Getinput.GetUserInput();

        if (choice == 1)
        {
            Maze maze(numrows, numcoloumns); // Skapa en ny instans av Maze

            maze.generate();
            std::cout << "Maze generated" << std::endl;
            std::cout << std::endl;
            maze.draw();

            int answer;
            std::cout << "Vill du avsluta labyrinten? [1.Nej 2.Ja]" << std::endl;
            answer = Getinput.GetUserInput();

            if (answer == 2)
            {
                std::cout << "Avslutar programmet." << std::endl;
                break; // Avsluta loopen och programmet
            }
            else if (answer == 1)
            {
                Maze newMaze(numrows, numcoloumns);

                std::cout << "Genererar en ny labyrint.." << std::endl;
                newMaze.generate();
                newMaze.draw();
            }
        }
        else if (choice == 2)
        {
            std::cout << "Avslutar programmet." << std::endl;
            break; // Avsluta loopen och programmet
        }
        else
        {
            std::cout << "Välj en siffra 1 eller 2." << std::endl;
        }
    }

    return 0;
}