// Handledare: Jimmy Åhlander
// Student: Only Badle
// Redigerat: 15/8/2023
// betyg E
#ifndef KLASS_H
#define KLASS_H
#include <iostream>
#include <random>
#include <ctime>
#include <algorithm>

class Maze
{
public:
  Maze(int numrows, int numcoloumns) : rows(numrows), cols(numcoloumns)
  {
    grid.resize(rows, std::vector<Nod>(cols));
  }

  void generate();
  void draw();

  int GetUserInput();

private:
  int rows, cols;

  struct Nod
  {
    bool right, left, up, down;
    bool visited;

    Nod() : visited(false) {}
  };
  std::vector<std::vector<Nod>> grid;
  std::vector<std::pair<int, int>> FindUnvisited(int row, int col);
  void generateDFS(int rows, int cols);
  void removeWalls(int current_row, int current_col, int next_row, int next_col);
};

#endif