// Handledare: Jimmy Åhlander
// Student: Only Badle
// Redigerat: 15/8/2023
// betyg E
#include "klass.h"

std::vector<std::pair<int, int>> Maze::FindUnvisited(int row, int col)
{
    std::vector<std::pair<int, int>> neighbors;

    // kolla om det finns obesökta grannar
    if (row > 0 && !grid[row - 1][col].visited)
    {

        neighbors.push_back(std::make_pair(row - 1, col));
    }
    if (col > 0 && !grid[row][col - 1].visited)
    {

        neighbors.push_back(std::make_pair(row, col - 1));
    }
    if (row < rows - 1 && !grid[row + 1][col].visited)
    {

        neighbors.push_back(std::make_pair(row + 1, col));
    }
    if (col < cols - 1 && !grid[row][col + 1].visited)
    {

        neighbors.push_back(std::make_pair(row, col + 1));
    }

    return neighbors;
}
void Maze::removeWalls(int current_row, int current_col, int next_row, int next_col)
{
    if (next_row == current_row - 1)
    {
        grid[current_row][current_col].up = false;
        grid[next_row][next_col].down = false;
    }
    else if (next_row == current_row + 1)
    {
        grid[current_row][current_col].down = false;
        grid[next_row][next_col].up = false;
    }
    else if (next_col == current_col - 1)
    {
        grid[current_row][current_col].left = false;
        grid[next_row][next_col].right = false;
    }
    else if (next_col == current_col + 1)
    {
        grid[current_row][current_col].right = false;
        grid[next_row][next_col].left = false;
    }
}

void Maze::generateDFS(int row, int col)
{
    if (row < 0 || row >= rows || col < 0 || col >= cols || grid[row][col].visited)
        return;

    grid[row][col].visited = true;

    std::vector<std::pair<int, int>> neighbors = FindUnvisited(row, col);

    while (!neighbors.empty())
    {
        int random_index = rand() % neighbors.size();
        int next_row = neighbors[random_index].first;
        int next_col = neighbors[random_index].second;

        removeWalls(row, col, next_row, next_col);

        generateDFS(next_row, next_col);
        neighbors = FindUnvisited(row, col);
    }
}



void Maze::generate()
{

    generateDFS(0, 0);
}

void Maze::draw()
{
    // Rita ut labyrinten
    std::cout << "S";

    for (int j = 1; j < cols; j++)
    {
        std::cout << "+--- ";
    }

    std::cout << "E" << std::endl;

    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            if (j == 0 || grid[i][j].left)
            {
                std::cout << "|";
            }
            else
            {
                std::cout << " ";
            }

            std::cout << "   ";
        }
        std::cout << "|\n";

        for (int j = 0; j < cols; j++)
        {
            if (i < rows - 1 && (grid[i][j].down || grid[i + 1][j].up))
            {
                std::cout << "+---";
            }
            else
            {
                std::cout << "+   ";
            }
        }
        std::cout << "+\n";
    }

    for (int j = 0; j < cols; j++)
    {
        std::cout << "+---";
    }
    std::cout << "+\n";
}

int Maze::GetUserInput() // rätt input
{
    int input;
    while (true)
    {
        std::cout << "Ange ditt val: ";
        if (std::cin >> input)
        {

            break;
        }
        else
        {
            std::cout << "Ogiltig inmatning. Inmatningen ska vara en siffra." << std::endl;
            std::cin.clear();                                                   // Nollställ felstatus
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Rensa inmatningsbufferten
        }
    }
    return input;
}
